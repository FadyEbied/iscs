package com.example.iscs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IscsApplication {

    public static void main(String[] args) {
        SpringApplication.run(IscsApplication.class, args);
    }

}
