package com.example.iscs.utils;

public enum FootballHeaders {
    TEAM,
    P,
    W,
    L,
    D,
    F,
    A,
    Pts

}
