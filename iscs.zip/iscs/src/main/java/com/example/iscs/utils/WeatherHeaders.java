package com.example.iscs.utils;

public enum WeatherHeaders {

    Dy,
    MxT,
    MnT,
    AvT,
    HDDay,
    AvDP,
    lHrP,
    TPcpn,
    WxType,
    PDir,
    AvSp,
    Dir,
    MxS,
    SkyC,
    MxR,
    MnR,
    AvSLP
}
