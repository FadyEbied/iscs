package com.example.iscs.controllers;

import org.springframework.stereotype.Controller;

@Controller("/inputFiles")
public class IscsInputFileController {
}
